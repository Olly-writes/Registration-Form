import { useRef } from 'react';

export default function App() {
  const fileInputRef = useRef();

  const handleUploadClick = () => {
    fileInputRef.current.click();
  };

  return (
    <div className="container">
      <h1>REGISTRATION FORM</h1>
      <div className="card">
        {/* Left column */}
        <div>
          <div className="form-field">
            <label>Kayak ID</label>
            <input type="text" defaultValue="KAY-013" />
          </div>
          <div className="form-field">
            <label>Kayak Name</label>
            <input type="text" placeholder="" />
          </div>
          <div className="form-field">
            <label>Type</label>
            <select><option value="">Select</option></select>
          </div>
          <div className="form-field">
            <label>No. People</label>
            <select><option value="">Select</option></select>
          </div>
          <div className="form-field">
            <label>Activity Type</label>
            <select><option value="">Select</option></select>
          </div>
          <div className="form-field">
            <label>Skill Level</label>
            <select><option value="">Select</option></select>
          </div>
          <div className="form-field">
            <label>Weight</label>
            <select><option value="">Select</option></select>
          </div>
        </div>

        {/* Right column */}
        <div>
          <div className="form-field">
            <label>Height</label>
            <select><option value="">Select</option></select>
          </div>
          <div className="form-field">
            <label>Width</label>
            <select><option value="">Select</option></select>
          </div>
          <div className="form-field">
            <label>Status</label>
            <select><option value="">Select</option></select>
          </div>

          <div className="form-field">
            <label>Kayak Images <span style={{ color: '#ef4444' }}>*</span></label>
            <small style={{ color: '#475569', marginBottom: '6px' }}>Image size must be less than 5Mb</small>
            <div className="upload-area" onClick={handleUploadClick}>
              Click to upload or drag and drop<br/>SVG, PNG, JPG or GIF (max. 800×400px)
            </div>
            <input
              type="file"
              accept="image/*"
              ref={fileInputRef}
              style={{ display: 'none' }}
            />
          </div>

          <div className="form-field">
            <label>Admin Notes</label>
            <textarea rows="3" placeholder="Add admin notes" />
          </div>
        </div>
      </div>
    </div>
  );
}
